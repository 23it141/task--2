import React from 'react';

function AboutMe() {
  return (
    <div className="about-me">
      <h2>About Me</h2>
      <p>Hello! I'm Ellis Zalavadiya, a passionate developer excited to build modern web applications.</p>
    </div>
  );
}

export default AboutMe;
