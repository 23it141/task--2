import React from 'react';

function Projects() {
  return (
    <div className="projects">
      <h2>Projects</h2>
      <ul>
        <li>
          <strong>Project 1:</strong> mern chat-app.
        </li>
        <li>
          <strong>Project 2:</strong> SIH project.
        </li>
      </ul>
    </div>
  );
}

export default Projects;
